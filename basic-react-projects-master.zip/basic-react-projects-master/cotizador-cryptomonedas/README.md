# Cryptocurrency Quote

Website link [Cryptocurrency Quote](https://cotizador-cryptomonedas-mrivera.netlify.app/).

## Summary

This is project 6/10, this project has a form that asks for a currency and a cryptocurrency, after adding this information if the button is pressed a loading screen is generated and after 2 seconds a report of the value of said cryptocurrency. 

### Learning 

In the development of this project, I learned: 
- To use an api that asks for two parameters => [API](https://www.cryptocompare.com/).
- To use the axios library to consult the api.
- To create custom hooks.

### Run Locally

- Clone the repository `https://github.com/RiveraMariano/react-projects.git`.
- The project is on the `cotizador-cryptomonedas` folder.
- Open the cmd and get the project route.
- Run `npm install` for the dependencies.
- Run `npm start` (The project should run in the default browser).
