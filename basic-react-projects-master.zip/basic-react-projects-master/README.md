# Context

This is my first repository dedicated to the javascript framework, the main reason why I decided to learn how to use this technology is because in the future when I finish my studies I would like to specialize professionally as a web developer, because I think it is one of the great programming fields of the future. If you have any questions or improvements for the projects, feel free to contact me about it.

### Introduction 

This is a series of 10 basic react.js projects developed by me as a requirement of a Udemy online academy programming course. Developing these 10 projects I learned how to use three of the most important react hooks: useState, useEffect and useContext, as well as learning how to create custom hooks. I also learned to consult api's and to implement different style libraries that are well known and will be seen as the projects progress.

### Tech Stack

- React.js
- React Hooks
- React Custom Hooks
- Netlify
- API's
