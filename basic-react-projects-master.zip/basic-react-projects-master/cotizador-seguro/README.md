# Insurance Quote

Website link [Insurance Quote](https://cotizador-seguro-mrivera.netlify.app/).

## Summary

This is project 3/10, this project to help you quote insurance for cars of different brands and years and choose a plan for this insurance. After quoting a loading screen is displayed and then the quote summary and total are displayed. 

### Learning 

In the development of this project, I learned: 
- To implement the spinkit loading screens => [Website](https://tobiasahlin.com/spinkit/).
- To use the Emotion style library.

### Run Locally

- Clone the repository `https://github.com/RiveraMariano/react-projects.git`.
- The project is on the `cotizador-seguro` folder.
- Open the cmd and get the project route.
- Run `npm install` for the dependencies.
- Run `npm start` (The project should run in the default browser).
