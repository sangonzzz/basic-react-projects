# Breaking Bad

Website link [Breaking Bad](https://breaking-bad-mrivera.netlify.app/).

## Summary  

This is project 4/10, this project generates random phrases from the “Breaking Bad” series and displays them on the screen. 

### Learning 

In the development of this project, I learned: 
- To consult api's and extract their information => [API](https://breaking-bad-quotes.herokuapp.com/v1/quotes).
- To use the async / await functions.

### Run Locally

- Clone the repository `https://github.com/RiveraMariano/react-projects.git`.
- The project is on the `breaking-bad` folder.
- Open the cmd and get the project route.
- Run `npm install` for the dependencies.
- Run `npm start` (The project should run in the default browser).
