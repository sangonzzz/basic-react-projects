# Get Wheater

Website link [Get Wheater](https://obtener-clima-mrivera.netlify.app/).

## Summary

This is project 5/10, this project has a form that asks for a country and a city, after adding this information, if the button is pressed, a weather report is generated. 

### Learning 

In the development of this project, I learned: 
- To use an api that asks for three parameters => [API](https://openweathermap.org/).
- To read the values of a select and put them inside the state.

### Run Locally

- Clone the repository `https://github.com/RiveraMariano/react-projects.git`.
- The project is on the `obtener-clima` folder.
- Open the cmd and get the project route.
- Run `npm install` for the dependencies.
- Run `npm start` (The project should run in the default browser).
